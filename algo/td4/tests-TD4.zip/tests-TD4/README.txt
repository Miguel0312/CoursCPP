Pour tester votre application de tas binaire (TD4) il suffit d'avoir un executable dont le nom est td4 dans le répertoire courant et de lancer le script tests.sh avec la commande :
$ bash tests.sh
